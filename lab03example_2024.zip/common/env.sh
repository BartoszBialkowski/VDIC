source /cad/etc/lm_license_file
# source /eda/cadence/2021-22/scripts/XCELIUM_21.03.009_RHELx86.sh
# source /eda/cadence/2021-22/scripts/VMANAGER_21.03.003_RHELx86.sh
source /eda/cadence/2023-24/scripts/XCELIUM_23.03.007_RHELx86.sh
source /eda/cadence/2023-24/scripts/VMANAGER_23.03.004_RHELx86.sh
