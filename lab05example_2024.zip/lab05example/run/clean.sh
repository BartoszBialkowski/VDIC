#!/bin/bash
rm -rf cov_work
rm -f *.log
rm -rf INCA_libs*
rm -f *.history
rm -f *.rpt
rm -f imc.key
